## 1.0.0

Initial Release + Replaced Hunter sound with Ronnie McNutt sound.

## 1.0.1

Fixed the bug where you can't hear the sound of Ronnie McNutt.

## 1.0.2

Moderators took down this mod. If this is taken down one more time, I will consider reuploading it on GitHub.

